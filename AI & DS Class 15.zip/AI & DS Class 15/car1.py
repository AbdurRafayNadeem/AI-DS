{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [
    {
     "ename": "IndentationError",
     "evalue": "expected an indented block (<ipython-input-3-ea62a7b2b552>, line 4)",
     "output_type": "error",
     "traceback": [
      "\u001b[1;36m  File \u001b[1;32m\"<ipython-input-3-ea62a7b2b552>\"\u001b[1;36m, line \u001b[1;32m4\u001b[0m\n\u001b[1;33m    self.make = make\u001b[0m\n\u001b[1;37m       ^\u001b[0m\n\u001b[1;31mIndentationError\u001b[0m\u001b[1;31m:\u001b[0m expected an indented block\n"
     ]
    }
   ],
   "source": [
    "class Car():\n",
    " \"\"\"A simple attempt to represent a car.\"\"\"\n",
    " def __init__(self, make, model, year):\n",
    " self.make = make\n",
    " self.model = model\n",
    " self.year = year\n",
    " self.odometer_reading = 0\n",
    "\n",
    " def get_descriptive_name(self):\n",
    " long_name = str(self.year) + ' ' + self.make + ' ' + self.model\n",
    " return long_name.title()\n",
    "\n",
    " def read_odometer(self):\n",
    " print(\"This car has \" + str(self.odometer_reading) + \" miles on it.\")\n",
    "\n",
    " def update_odometer(self, mileage):\n",
    " if mileage >= self.odometer_reading:\n",
    " self.odometer_reading = mileage\n",
    " else:\n",
    " print(\"You can't roll back an odometer!\")\n",
    "\n",
    " def increment_odometer(self, miles):\n",
    " self.odometer_reading += miles"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
